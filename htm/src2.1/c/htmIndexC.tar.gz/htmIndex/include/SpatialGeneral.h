#if !defined (_SpatialGeneral_h)
#define _SpatialGeneral_h
/*
//# SpatialGeneral.h
//#
//# This file contains all SDSS Science Archive global information,
//# including Global Type Definitions, Global Macros, and Global Inlines
//#
//# Author:		Peter Z. Kunszt
//#	
//# Creation:		October 19, 1999
//#
//# (c) Copyright The Johns Hopkins University 1999
//# All Rights Reserved
//#
//# The software and information contained herein are proprietary to The
//# Johns Hopkins University, Copyright 1995, 1996. This software is furnished
//# pursuant to a written license agreement and may be used, copied,
//# transmitted, and stored only in accordance with the terms of such
//# license and with the inclusion of the above copyright notice.  This
//# software and information or any other copies thereof may not be
//# provided or otherwise made available to any other person.
//#
//# Modification History:

// Type Definitions

// define portable int and float types where not already defined
// The SDSS Science Archive and Objectivity define the very same thing.
//	Objectivity defines these in ooMachine.h (version 4) and
//	in ooConfig.h (version 5).
//
//      SX defines these in sxGeneral.h

// The following list is for different machines:
//
// ------------------------------------------------------------------------
// MACHINE |  CHAR | SHORT |   INT |  LONG | FLOAT | DOUBLE | LONG DOUBLE |
// ------------------------------------------------------------------------
//  SUN    |    8  |   16  |   32  |   32  |   32  |   64   |   128       |
// ------------------------------------------------------------------------
//  ALPHA  |    8  |   16  |   32  |   64  |   32  |   64   |    64       |
// ------------------------------------------------------------------------
//  SGI-n32|    8  |   16  |   32  |   32  |   32  |   64   |   128       |
// ------------------------------------------------------------------------
//  SGI    |    8  |   16  |   32  |   32  |   32  |   64   |    64       |
// ------------------------------------------------------------------------
//  NT     |    8  |   16  |   32  |   32  |   32  |   64   |    64       |
// ------------------------------------------------------------------------
//  LINUX  |    8  |   16  |   32  |   32  |   32  |   64   |    96       |
// ------------------------------------------------------------------------
//
*/
#if !defined(OO_MACHINE_H) && !defined(OO_CONFIG_H) && !defined(SXGENERAL_H)
typedef char			int8;
typedef unsigned char		uint8;
typedef short int		int16;
typedef unsigned short int	uint16;
typedef int			int32;
typedef unsigned int		uint32;
typedef long long		int64;
typedef unsigned long long	uint64;
typedef float			float32;
typedef double			float64;
#endif

#ifdef HTM_LONG_ID
#define IDTYPE                 uint64
#define IDSIZE                     64
#define IDHIGHBIT  0x8000000000000000LL
#define IDHIGHBIT2 0x4000000000000000LL
#define HTMNAMEMAX                 32
#define IDFMT                   "%llu"
#define IDFMTX                  "%llx"
#else
#define IDTYPE                 uint32
#define IDSIZE                     32
#define IDHIGHBIT          0x80000000
#define IDHIGHBIT2         0x40000000
#define HTMNAMEMAX                 16
#define IDFMT                    "%u"
#define IDFMTX                   "%x"
#endif


#define HTM_READBUFSIZE           512
/* emulate the standard bool type where not supported by compiler */

typedef unsigned char           bool;

#define PICONST 3.1415926535897932385
#ifdef HTM_LIB

extern const bool                      false;
extern const bool                      true;

/* Global Math Constants */

extern const float64 gPi;
extern const float64 gEpsilon;
extern const float64 gPr;

#else

const bool                      false = 0;
const bool                      true = 1;

/* Global Math Constants */

const float64 gPi = PICONST ;
const float64 gEpsilon = 1.0E-15;
const float64 gPr = PICONST/180.0; 

#endif

/* CVSversion = "$Name:  $";  */

#endif /* SPATIALGENERAL_H */
