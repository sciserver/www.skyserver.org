#ifndef _SpatialMarkup_h
#define _SpatialMarkup_h
/*
//#     Filename:       SpatialMarkup.h
//#
//#     SpatialMarkup is the class for the the sky Markup routines.
//#
//#
//#     Author:         Peter Z. Kunszt, based on A. Szalay's code
//#     
//#     Date:           October 15, 1998
//#
//#
//#
//# (c) Copyright The Johns Hopkins University 1998
//# All Rights Reserved
//#
//# The software and information contained herein are proprietary to The
//# Johns Hopkins University, Copyright 1998.  This software is furnished
//# pursuant to a written license agreement and may be used, copied,
//# transmitted, and stored only in accordance with the terms of such
//# license and with the inclusion of the above copyright notice.  This
//# software and information or any other copies thereof may not be
//# provided or otherwise made available to any other person.
//#
//#
*/
#include "SpatialIndex.h"

/* The Spatial Markup just keeps track of the state of each node in the
   SkyIndex tree during an intersection with a domain.
*/

#define  dONTKNOW  0
#define  pARTIAL   1
#define  sWALLOWED 2
#define  fULL      3
#define  rEJECT    4
#define  bREJECT   5

#define  vTRUE     1
#define  vFALSE    2
#define  vUNDEF    0

typedef struct {
  const  SpatialIndex * index;
  uint8  *mark_;	/* Array of node markers */
  uint8  *vmark_;	/* Array of vertex markers (true, false, undef) */
  size_t markLen_;
  size_t vmarkLen_;
} SpatialMarkup;

/* Constructor: specify index */
SpatialMarkup * spatialMarkupNew( const SpatialIndex * );

/* Copy Constructor */
SpatialMarkup * spatialMarkupCopy( const SpatialMarkup * );

/* reset node markup to reject */
void spatialMarkupClear( SpatialMarkup * );

/* reset vertex markup to undefined */
void spatialMarkupClearVertex( SpatialMarkup * );

#endif
