#ifndef _SpatialDomain_h
#define _SpatialDomain_h
/*
//#     Filename:       SpatialDomain.h
//#
//#     Classes defined here: SpatialDomain
//#
//#
//#     Author:         Peter Z. Kunszt
//#     
//#     Date:           October 16, 1998
//#
//#
//#
//# (c) Copyright The Johns Hopkins University 1998-1999
//# All Rights Reserved
//#
//# The software and information contained herein are proprietary to The
//# Johns Hopkins University, Copyright 1999.  This software is furnished
//# pursuant to a written license agreement and may be used, copied,
//# transmitted, and stored only in accordance with the terms of such
//# license and with the inclusion of the above copyright notice.  This
//# software and information or any other copies thereof may not be
//# provided or otherwise made available to any other person.
//#
//#
*/

#include "SpatialConvex.h"
#include "BitList.h"

typedef struct {
  SpatialConvexVec convexes_;   /* The vector of convexes */
  SpatialMarkup *markup_;	/* The markup class */
  const SpatialIndex * index_;	/* A pointer to the index */
} SpatialDomain;

/* Constructors */
SpatialDomain * spatialDomainNew();
SpatialDomain * spatialDomainNewIdx( const SpatialIndex * idx );

/* Destructor */
void spatialDomainDelete( SpatialDomain * );

/* Set index pointer and initialize markup if not done with constructor */
void spatialDomainSetIndex( SpatialDomain *d, const SpatialIndex *);

/* Add a convex */
void spatialDomainAdd( SpatialDomain *d, SpatialConvex *);

/* Initialize the domain */
void spatialDomainInit( SpatialDomain *d );

/* Simplify the Domain, remove redundancies */
void spatialDomainSimplify( SpatialDomain *d );

/* Intersect with index. Return the bitlist of the leafnodes that are
   partially and fully intersected by this domain. */
bool spatialDomainIntersectBit( SpatialDomain *d, 
				const SpatialIndex * idx, 
				BitList * partial, BitList * full);

/* Same intersection, but return vectors of ids instead of bitlists. */
bool spatialDomainIntersectList( SpatialDomain *d, 
				 const SpatialIndex * idx, 
				 SpatialIDVec * partial, SpatialIDVec * full);

/* write out vertex markup to a stream */
void spatialDomainShowVertexMarkup( const SpatialDomain *d, FILE*);

/* numConvexes: give back the number of convexes */
size_t spatialDomainNumConvexes( const SpatialDomain *d );

void spatialDomainGetToken( FILE *in, float64 *val, char *err );

/* read from stream */
void spatialDomainRead( SpatialDomain *d, FILE *);

/* write to stream */
void spatialDomainWrite( const SpatialDomain *d, FILE *);


/* void ignoreCrLf(FILE *); */

#endif
