#ifndef _SpatialConstraint_h
#define _SpatialConstraint_h
/*
//#     Filename:       SpatialConstraint.h
//#
//#     Classes defined here: SpatialConstraint SpatialSign
//#
//#
//#     Author:         Peter Z. Kunszt, based on A. Szalay's code
//#     
//#     Date:           October 16, 1998
//#
//#
//#
//# (c) Copyright The Johns Hopkins University 1998
//# All Rights Reserved
//#
//# The software and information contained herein are proprietary to The
//# Johns Hopkins University, Copyright 1998.  This software is furnished
//# pursuant to a written license agreement and may be used, copied,
//# transmitted, and stored only in accordance with the terms of such
//# license and with the inclusion of the above copyright notice.  This
//# software and information or any other copies thereof may not be
//# provided or otherwise made available to any other person.
//#
//#
*/
#include "SpatialVector.h"

/*
//########################################################################
//
// <GROUP>
// <SUMMARY>Class declarations</SUMMARY>
// 
//########################################################################
//
// <SUMMARY> Spatial Sign helper class </SUMMARY>
//
// The sign class is inherited by Constraint and Convex. Assignment and
// copy operators are used in both scopes.
*/

typedef enum {
  nEG  = 0,			/* All constraints negative or zero */
  zERO = 1,			/* All constraints zero */
  pOS  = 2,			/* All constraints positive or zero */
  mIXED= 3 			/* At least one pos and one neg */
} Sign;

/*
//########################################################################
//
// <SUMMARY> Spatial Constraint class </SUMMARY>
//
// The Constraint is really a cone on the sky-sphere. It is characterized
// by its direction a_, the opening angle s_ and its cosine -- the distance
// of the plane intersecting the sphere and the sphere center.
// If d_ = 0, we have a half-sphere. If it is negative, we have a 'hole'
// i.e. the room angle is larger than 90degrees.
//
// Example: positive distance
//<srcblock>
//                   ____
//                ---    ---
//               /        /|\
//              /        / |=\
//             |        /  |==|     this side is in the convex.
//            |        /\s |===|
//            |------------|---| -> direction a
//            |        \   |===|
//             |        \  |==|
//              \        \ |=/
//               \        \|/
//                ---____---
//
//
//                     <-d-> is positive (s < 90)
//
//</srcblock>
// Example: negative distance
//<srcblock>
//                   ____
//                ---====---
//  this side is /========/|\
//  in the      /========/=| \
//  convex     |==== s__/==|  |
//            |===== / /===|   |
//  dir. a <- |------------|---|  'hole' in the sphere
//            |========\===|   |
//             |========\==|  |
//              \========\=| /
//               \========\|/
//                ---____---
//
//
//                     <-d-> is negative (s > 90)
//</srcblock>
// for d=0 we have a half-sphere. Combining such, we get triangles, rectangles
// etc on the sphere surface (pure ZERO convexes)
//
*/

typedef struct {
  SpatialVector a_;			/* normal vector */
  float64       d_;			/* distance from origin */
  float64       s_;			/* cone angle in radians */
  Sign          sign_;			/* Sign */
} SpatialConstraint;

typedef struct {
  SpatialConstraint *vector_;
  size_t 	    length_;
  size_t            capacity_;
} SpatialConstraintVec;

/* Constructor */
SpatialConstraint * spatialConstraintNew();

/* Destructor */
void spatialConstraintDelete( SpatialConstraint *c );

/* Initialization constructor */
SpatialConstraint * spatialConstraintNewVec( const SpatialVector *v, 
					     float64 d );

/* initialize to empty */
void spatialConstraintInit( SpatialConstraint * c ) ;

/* Copy constructor */
SpatialConstraint * spatialConstraintCopy( const SpatialConstraint *c );

/* Assignment */
void spatialConstraintAssign( SpatialConstraint *c1, 
			      const SpatialConstraint *c2 );

/* set it to a new value */
void spatialConstraintSet( SpatialConstraint *c, 
			   const SpatialVector *v, float64 d );

/* Invert */
void spatialConstraintInvert( SpatialConstraint *c );

/* check whether a vector is inside this */
bool spatialConstraintContains( const SpatialConstraint *c, 
				const SpatialVector *v );

/* read */
void spatialConstraintRead( SpatialConstraint *c, FILE *in);

/* read */
void spatialConstraintReadRaDec( SpatialConstraint *c, FILE *in);

/* write */
void spatialConstraintWrite( const SpatialConstraint *c, FILE *out);

/* append a new element in spatialconstraintvec */
size_t spatialConstraintVecAppend( SpatialConstraintVec *, 
				   const SpatialConstraint * );

/* clear spatialconstraintvec */
void spatialConstraintVecClear( SpatialConstraintVec *, bool );

/* remove an item from the list */
void spatialConstraintVecRemove( SpatialConstraintVec *v , size_t index );

#endif
