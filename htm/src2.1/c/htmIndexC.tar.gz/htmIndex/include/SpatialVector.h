#ifndef _SpatialVector_h
#define _SpatialVector_h
/*
//#     Filename:       SpatialVector.h
//#
//#     Standard 3-d vector class
//#
//#
//#     Author:         Peter Z. Kunszt, based on A. Szalay's code
//#     
//#     Date:           October 15, 1998
//#
//#
//#
//# (c) Copyright The Johns Hopkins University 1998
//# All Rights Reserved
//#
//# The software and information contained herein are proprietary to The
//# Johns Hopkins University, Copyright 1998.  This software is furnished
//# pursuant to a written license agreement and may be used, copied,
//# transmitted, and stored only in accordance with the terms of such
//# license and with the inclusion of the above copyright notice.  This
//# software and information or any other copies thereof may not be
//# provided or otherwise made available to any other person.
//#
//#
*/
#include <math.h>
#include <stdio.h>
#include "SpatialGeneral.h"

/*
//########################################################################
//
// <SUMMARY> Spatial Vector class </SUMMARY>
//
// The SpatialVector is a 3D vector usually living on the surface of
// the sphere. The corresponding ra, dec can be obtained if the vector
// has unit length. That can be ensured with the normalize() function.
//
*/

typedef struct {
  float64 x_;
  float64 y_;
  float64 z_;
  float64 ra_;
  float64 dec_;
  bool okRaDec_;
} SpatialVector;

typedef struct {
  SpatialVector *vector_;
  size_t 	length_;
  size_t        capacity_;
} SpatialVectorVec;


/* constructs (1,0,0), ra=0, dec=0. */
SpatialVector* spatialVectorNew( );

/* destructor */
void spatialVectorDelete( SpatialVector *v );

/* Constructor from three coordinates, not necessarily normed to 1 */
SpatialVector* spatialVectorNewXYZ( float64 x,
				    float64 y,
				    float64 z );

/* Constructor from ra/dec, this is always normed to 1 */
SpatialVector* spatialVectorNewRaDec( float64 ra,
				      float64 dec );

/* Copy constructor */
SpatialVector* spatialVectorNewCopy( const SpatialVector *v );

/* Assignment */
void spatialVectorAssign( SpatialVector *v1, const SpatialVector * v2 );

/* Set member function: set values - always normed to 1 */
void spatialVectorSet( SpatialVector *v,
		       const float64 x,
		       const float64 y,
		       const float64 z );

/* Set member function: set values - always normed to 1 */
void spatialVectorSetRaDec( SpatialVector *v,
			    const float64 ra,
			    const float64 dec );

/* Get x,y,z */
void spatialVectorGet( SpatialVector *v,
		       float64 *x,
		       float64 *y,
		       float64 *z );

/* Get ra,dec - normalizes x,y,z */
void spatialVectorGetRaDec( SpatialVector *v,
			    float64 *ra,
			    float64 *dec );

/* calculate and return ra */
float64 spatialVectorRa( SpatialVector *v );

/* calculate and return dec */
float64 spatialVectorDec( SpatialVector *v );

/* return length of vector */
float64 spatialVectorLength( const SpatialVector *v );

/* Normalize vector length to 1 */
void spatialVectorNormalize( SpatialVector *v );

/* Printf it to stdout */
void spatialVectorShow( const SpatialVector *v );

/* Read vector from a stream */
void spatialVectorRead( SpatialVector *v, FILE * );

/* Write vector to a stream */
void spatialVectorWrite( const SpatialVector *v, FILE * );

/* Comparison */
int spatialVectorEQ( const SpatialVector *v1, const SpatialVector *v2 );

/* dot product */
float64 spatialVectorDot( const SpatialVector *v1, const SpatialVector*v2 );

/* cross product */
SpatialVector * spatialVectorCrossNew( const SpatialVector *v1, 
				       const SpatialVector*v2 );

/* addition */
SpatialVector * spatialVectorAddNew( const SpatialVector *v1, 
				     const SpatialVector*v2 );

/* subtraction */
SpatialVector * spatialVectorSubNew( const SpatialVector *v1, 
				     const SpatialVector*v2 );

/* cross product */
void spatialVectorCrossNorm( const SpatialVector *v1, const SpatialVector*v2, 
			     SpatialVector *v );

/* addition */
void spatialVectorAddNorm( const SpatialVector *v1, const SpatialVector*v2,
			   SpatialVector *v );

/* subtraction */
void spatialVectorSubNorm( const SpatialVector *v1, const SpatialVector*v2,
			   SpatialVector *v );

/* cross product */
void spatialVectorCross( const SpatialVector *v1, const SpatialVector*v2, 
			 SpatialVector *v );

/* addition */
void spatialVectorAdd( const SpatialVector *v1, const SpatialVector*v2,
		       SpatialVector *v );

/* subtraction */
void spatialVectorSub( const SpatialVector *v1, const SpatialVector*v2,
		       SpatialVector *v );

/* multiply with a number */
void spatialVectorMul( SpatialVector *v, float64 n );

void spatialVectorUpdateXYZ( SpatialVector *v );
void spatialVectorUpdateRaDec( SpatialVector *v );

/* get a token from the stream */
char * getStreamToken( char *buf, FILE *f);

/* append a new element in spatialvectorvec */
void spatialVectorVecAppend( SpatialVectorVec *, const SpatialVector * );

/* clear spatialvectorvec */
void spatialVectorVecClear( SpatialVectorVec *, bool );
void spatialVectorVecInit( SpatialVectorVec *v );


#endif

