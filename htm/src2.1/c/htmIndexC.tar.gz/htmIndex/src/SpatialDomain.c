/*
//#     Filename:       SpatialDomain.c
//#
//#     The SpatialDomain functions are written here
//#
//#     Author:         Peter Z. Kunszt based on A. Szalay's code
//#     
//#     Date:           October 23, 1998
//#
//#
//#
//# (c) Copyright The Johns Hopkins University 1998
//# All Rights Reserved
//#
//# The software and information contained herein are proprietary to The
//# Johns Hopkins University, Copyright 1998.  This software is furnished
//# pursuant to a written license agreement and may be used, copied,
//# transmitted, and stored only in accordance with the terms of such
//# license and with the inclusion of the above copyright notice.  This
//# software and information or any other copies thereof may not be
//# provided or otherwise made available to any other person.
//#
//#
//#     Modification History:
//#
*/
#define HTM_LIB
#include "SpatialDomain.h"
#include "assert.h"

#define COMMENT '#'
/*
// ===========================================================================
//
// Member functions for class SpatialDomain
//
// ===========================================================================

/////////////CONSTRUCTOR//////////////////////////////////
//
// Initialize markup to be a full reject
//
*/
SpatialDomain * spatialDomainNew() {
  SpatialDomain *d = (SpatialDomain *)malloc(sizeof(SpatialDomain));
  spatialDomainInit(d);

  return d;
}
SpatialDomain * spatialDomainNewIdx( const SpatialIndex * idx )
{
  SpatialDomain *d = spatialDomainNew();
  d->index_ = idx;
  if(idx)d->markup_ = spatialMarkupNew(idx);
  return d;
}

/* /////////////DESTRUCTOR///////////////////////////////////
 */
void spatialDomainDelete( SpatialDomain *d ) {
  int i;
  if(d->markup_)free(d->markup_);
  for(i = 0; i < d->convexes_.length_; i++)
    spatialConvexDelete(&(d->convexes_.vector_[i]));
  free(d->convexes_.vector_);
}

/* /////////////INIT/////////////////////////////////////////
 * Initialize the domain */
void spatialDomainInit( SpatialDomain *d ) {
  d->index_  = NULL;
  d->markup_ = NULL;
  spatialConvexVecInit( &(d->convexes_) );
}

/* /////////////SETINDEX/////////////////////////////////////
 */
void spatialDomainSetIndex( SpatialDomain *d, const SpatialIndex *idx)
{
  /* set index and markup pointers */
  d->index_ = idx;
  if(d->markup_)free(d->markup_);
  d->markup_ = spatialMarkupNew(idx);
}

/* /////////////ADD//////////////////////////////////////////
 */
void spatialDomainAdd( SpatialDomain *d, SpatialConvex *c)
{
  spatialConvexVecAppend( &(d->convexes_), c );
}


/* /////////////INTERSECT////////////////////////////////////
 */
bool spatialDomainIntersectBit( SpatialDomain *d, 
				const SpatialIndex * idx, 
				BitList * partial, BitList * full)
{
  size_t i;

  /* set index and markup pointers */
  if(idx != NULL)d->index_ = idx;
  if(d->markup_ == NULL)d->markup_ = spatialMarkupNew(d->index_);

  if ( d->index_->maxlevel_ > 10 )
    printf( "WARNING: Intersection with Bitlists more than 10 levels deep is impractical.\n");

  /* initialize empty lists */
  bitListClear( full, false ); bitListClear( partial, false );
  bitListSet( full, (uint32)(d->index_->leaves_-1), false);
  bitListSet( partial, (uint32)(d->index_->leaves_-1), false);

  for(i = 0; i < d->convexes_.length_; i++)  /* intersect every convex */
    spatialConvexIntersectBit( &(d->convexes_.vector_[i]), d->index_, 
			       d->markup_, partial, full);

  return true;
}

/* /////////////INTERSECT////////////////////////////////////
 */
bool spatialDomainIntersectList( SpatialDomain *d, 
				 const SpatialIndex * idx, 
				 SpatialIDVec * partial, SpatialIDVec * full)
{
  size_t i;

  /* set index and markup pointers */
  if(!d->index_)d->index_ = idx;
  if(!d->markup_)d->markup_ = spatialMarkupNew(d->index_);

  /* initialize empty lists */
  spatialIDVecClear( full , false );
  spatialIDVecClear( partial , false );

  for(i = 0; i < d->convexes_.length_; i++)  /* intersect every convex */
    spatialConvexIntersect( &(d->convexes_.vector_[i]), d->index_, 
			    d->markup_, partial, full);

  return true;
}

/* /////////////SHOWVERTEXMARKUP/////////////////////////////
 */
void spatialDomainShowVertexMarkup( const SpatialDomain *d, FILE *out)
{
  size_t i;
  if(!d->markup_)return;

  for(i = 0; i < d->markup_->vmarkLen_-1; i++)
    fprintf(out, "%d\n", (d->markup_->vmark_[i] == vFALSE ? 0 : 1) );
}

/*
void ignoreCrLf( FILE * );
  char c = in.peek();
  while (c == 10 || c == 13) {
    in.ignore();
    c = in.peek();
  }
}
*/

/* /////////////READ/////////////////////////////////////////
 */
void spatialDomainRead( SpatialDomain *d, FILE *in)
{
  size_t nconv,i;
  SpatialConvex *conv, *tmp;
  SpatialVector v1,v2,v3,v4;
  float64 ra1,ra2,ra3,ra4;
  float64 dec1,dec2,dec3,dec4;
  char buffer[HTM_READBUFSIZE];
  char first;
  buffer[0] = '\0';

  /* ignore lines that begin with the comment character */
  first = (char)getc(in);
  while(first == COMMENT) {
    fgets(buffer, HTM_READBUFSIZE, in);
    first = (char)getc(in);
  }
  ungetc( (int)first, in );

  getStreamToken(buffer,in);
  nconv = atoi(buffer);

  for(i = 0; i < nconv; i++) {
    first = (char)getc(in);
    if(first == COMMENT) {
      ungetc( (int)first, in );
      getStreamToken(buffer,in);
    }
    else ungetc( (int)first, in );

    if(strcmp(buffer,"#TRIANGLE")==0) {
      spatialVectorRead( &v1, in );
      spatialVectorRead( &v2, in );
      spatialVectorRead( &v3, in );

      tmp = spatialConvexNewTriangle(&v1,&v2,&v3);
      spatialDomainAdd( d, tmp );
      free(tmp);
    } else if(strcmp(buffer,"#RECTANGLE")==0) {
      spatialVectorRead( &v1, in );
      spatialVectorRead( &v2, in );
      spatialVectorRead( &v3, in );
      spatialVectorRead( &v4, in );

      tmp = spatialConvexNewRectangle(&v1,&v2,&v3,&v4);
      spatialDomainAdd( d, tmp );
      free(tmp);
    } else if(strcmp(buffer,"#TRIANGLE_RADEC")==0) {
      spatialDomainGetToken( in, &ra1, buffer);
      spatialDomainGetToken( in, &dec1, buffer);
      spatialDomainGetToken( in, &ra2, buffer);
      spatialDomainGetToken( in, &dec2, buffer);
      spatialDomainGetToken( in, &ra3, buffer);
      spatialDomainGetToken( in, &dec3, buffer);

      spatialVectorSetRaDec( &v1, ra1, dec1 );
      spatialVectorSetRaDec( &v2, ra2, dec2 );
      spatialVectorSetRaDec( &v3, ra3, dec3 );
      tmp = spatialConvexNewTriangle(&v1,&v2,&v3);
      spatialDomainAdd( d, tmp );
      free(tmp);
    } else if(strcmp(buffer,"#RECTANGLE_RADEC")==0) {
      spatialDomainGetToken( in, &ra1, buffer);
      spatialDomainGetToken( in, &dec1, buffer);
      spatialDomainGetToken( in, &ra2, buffer);
      spatialDomainGetToken( in, &dec2, buffer);
      spatialDomainGetToken( in, &ra3, buffer);
      spatialDomainGetToken( in, &dec3, buffer);
      spatialDomainGetToken( in, &ra4, buffer);
      spatialDomainGetToken( in, &dec4, buffer);

      spatialVectorSetRaDec( &v1, ra1, dec1 );
      spatialVectorSetRaDec( &v2, ra2, dec2 );
      spatialVectorSetRaDec( &v3, ra3, dec3 );
      spatialVectorSetRaDec( &v4, ra4, dec4 );
      tmp = spatialConvexNewRectangle(&v1,&v2,&v3,&v4);
      spatialDomainAdd( d, tmp );
      free(tmp);
    } else  if(strcmp(buffer,"#CONVEX_RADEC")==0) {
      conv = spatialConvexNew();
      spatialConvexReadRaDec( conv, in );
      spatialDomainAdd( d, conv );
      spatialConvexDelete(conv);
    } else {
      conv = spatialConvexNew();
      spatialConvexRead( conv, in );
      spatialDomainAdd( d, conv );
      spatialConvexDelete(conv);
    }
    buffer[0] = 0;
  }
}

void spatialDomainGetToken( FILE *in, float64 *val, char *err ) {
  char buffer[HTM_READBUFSIZE];

  if(getStreamToken(buffer,in) == NULL) {
    printf("Failure: nothing to read for %s\n",err);
    assert(0);
  }
  sscanf(buffer,"%f", &val);
}

/* /////////////Write////////////////////////////////////////
 */
void spatialDomainWrite( const SpatialDomain *d, FILE *out)
{
  size_t i;
  fprintf(out,"#DOMAIN\n%d\n",d->convexes_.length_);
  for (i = 0; i < d->convexes_.length_ ; i++)
    spatialConvexWrite( &(d->convexes_.vector_[i]), out );
}

size_t spatialDomainNumConvexes( const SpatialDomain *d )
{
  return d->convexes_.length_;
}

