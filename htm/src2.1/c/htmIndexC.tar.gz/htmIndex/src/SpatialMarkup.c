/*
//#     Filename:       SpatialMarkup.c
//#
//#     The SpatialMarkup functions are here
//#
//#     Author:         Peter Z. Kunszt based on A. Szalay's code
//#     
//#     Date:           October 23, 1998
//#
//#
//#
//# (c) Copyright The Johns Hopkins University 1998
//# All Rights Reserved
//#
//# The software and information contained herein are proprietary to The
//# Johns Hopkins University, Copyright 1998.  This software is furnished
//# pursuant to a written license agreement and may be used, copied,
//# transmitted, and stored only in accordance with the terms of such
//# license and with the inclusion of the above copyright notice.  This
//# software and information or any other copies thereof may not be
//# provided or otherwise made available to any other person.
//#
//#
//#     Modification History:
//#
*/
#define HTM_LIB
#include "SpatialMarkup.h"


/* /////////////CONSTRUCTOR////////////////////////////////// */
SpatialMarkup * spatialMarkupNew( const SpatialIndex *index )
{
  int i;
  SpatialMarkup *mark = (SpatialMarkup *)malloc(sizeof(SpatialMarkup));

  mark->index = index;
  mark->mark_  = (uint8 *)malloc(sizeof(uint8) * index->nodes_.length_);
  mark->markLen_ = index->nodes_.length_;
  mark->vmark_ = (uint8 *)malloc(sizeof(uint8) * index->vertices_.length_);
  mark->vmarkLen_ = index->vertices_.length_;

  for(i = 0; i < mark->markLen_; i++) mark->mark_[i] = rEJECT;
  for(i = 0; i < mark->vmarkLen_; i++) mark->vmark_[i] = vUNDEF;

  return mark;
}

/* /////////////CONSTRUCTOR////////////////////////////////// */
SpatialMarkup * spatialMarkupCopy( const SpatialMarkup *m )
{
  int i;
  SpatialMarkup *mark;
  if(m == NULL) return NULL;
  mark = (SpatialMarkup *)malloc(sizeof(SpatialMarkup));

  if(m->index)mark->index     = m->index;
  mark->mark_     = (uint8 *)malloc(sizeof(uint8) * m->markLen_);
  memcpy(mark->mark_,m->mark_, sizeof(uint8) * m->markLen_);
  mark->markLen_  = m->markLen_;
  mark->vmark_    = (uint8 *)malloc(sizeof(uint8) * m->vmarkLen_);
  memcpy(mark->vmark_,m->vmark_, sizeof(uint8) * m->vmarkLen_);
  mark->vmarkLen_ = m->vmarkLen_;

  return mark;
}

/* /////////////CLEAR////////////////////////////////////////
// clear all markups to reject
*/
void spatialMarkupClear( SpatialMarkup *mark )
{
  int i;
  for(i = 0; i < mark->markLen_; i++) mark->mark_[i] = rEJECT;
}

/* /////////////CLEARVERTEX//////////////////////////////////
// clear vertex markups to undef
*/
void spatialMarkupClearVertex( SpatialMarkup *mark )
{
  int i;
  for(i = 0; i < mark->vmarkLen_; i++) mark->vmark_[i] = vUNDEF;
}


