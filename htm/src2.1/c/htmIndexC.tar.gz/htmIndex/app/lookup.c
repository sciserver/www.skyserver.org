/*
//#     Filename:       lookup.c
//#
//#     specify a point on the sphere, return its ID/Name to a certain depth
//#
//#
//#     Author:         Peter Z. Kunszt
//#
//#     Date:           October 15, 1999
//#
//#
//#
//# (c) Copyright The Johns Hopkins University 1999
//# All Rights Reserved
//#
//# The software and information contained herein are proprietary to The
//# Johns Hopkins University, Copyright 1999.  This software is furnished
//# pursuant to a written license agreement and may be used, copied,
//# transmitted, and stored only in accordance with the terms of such
//# license and with the inclusion of the above copyright notice.  This
//# software and information or any other copies thereof may not be
//# provided or otherwise made available to any other person.
//#
//#
*/
#include "SpatialVector.h"
#include "SpatialIndex.h"
#include <stdlib.h>

/*******************************************************
 
  DESCRIPTION
 
  This example code demonstrates the lookup functionality of
  the SpatialIndex.
 
  It can be invoked by
 
  	lookup level x y z

	or

	lookup level ra dec

  where

     level     : the level depth to build the index (2 - 14)
     x,y,z     : define a point on the unit sphere (can be non-unit vector)
     ra,dec    : "

  it echoes the vector and returns its ID/Name for the given level.


Example 1: level 5, ra,dec = 10,25

%lookup 5 10 25

	(x,y,z) = 0.892539 0.157379 0.422618
	(ra,dec) = 10,25
	ID/Name = 16020 N322110 

Example 2: level 14, x,y,z = -1,2,-23  (output is normed version)

% lookup 14 -1 2 -23

	(x,y,z) = -0.0432742 0.0865485 -0.995307
	(ra,dec) = 116.565,-84.4471
	ID/Name = 2486622255 S110031231200233

*******************************************************/

#define BUILDLEVEL 2

int
main(int argc, char *argv[]) {

/*******************************************************
//
// Initialization
//
********************************************************/

	SpatialIndex *index;
	SpatialVector *v;
	SpatialVector v1,v2,v3;
	float64 x,y,z,ra,dec;
	IDTYPE id;
	char name[50];

        bool radec=false;
	bool hex=false;		/* id in hex */
	bool area=false;	/* print area of node */
	bool corner=false;	/* print corners */

	int args = 1;
	argc--;

	/* parse options */
	while(argc > 0) {
	  if(strcmp(argv[args],"-h")==0)
	    hex=true;
	  else if(strcmp(argv[args],"-a")==0)
	    area = true;
	  else if(strcmp(argv[args],"-c")==0)
	    corner = true;
	  else if(strcmp(argv[args],"-v")==0) {
	    hex = true;
	    corner = true;
	    area = true;
	  } else break;
	  args++;
	  argc--;
	}

	/* read command line arguments */
	if(argc < 2 || argc > 4) {
	  printf("Usage: %s [options] depth x y z \n", argv[0]);
	  printf("or\n");
	  printf("       %s depth ra dec\n",argv[0]);
	  printf("or\n");
	  printf("       %s id\n",argv[0]);
	  printf("Options are: \n");
	  printf("-h  : print id in hexadecimal\n");
	  printf("-a  : print area of node\n");
	  printf("-c  : print corner vectors of node\n");
	  printf("-v  : verbose: all of the above\n");
	  return -1;
	}

	/* build the index to level 'depth' */
	if (argc == 2) { /* get depth from id length */
	  index = spatialIndexNew(strlen(argv[++args])-2, BUILDLEVEL );
	  printf("Depth = %d\n",strlen(argv[args])-2);
	} else
	  index = spatialIndexNew(atoi(argv[args++]), BUILDLEVEL ); 

	argc--;

	if(argc == 2)radec=true;

	/* read point and initialize*/
	if(radec) {
	  ra  = atof(argv[args++]);
	  dec = atof(argv[args]);
	} else if(argc > 1) {
	  x = atof(argv[args++]);
	  y = atof(argv[args++]);
	  z = atof(argv[args]);
	}

	if(radec)     /* initialize SpatialVector from ra,dec */
	  v = spatialVectorNewRaDec(ra,dec);
	else if (argc > 1){   /* initialize from x,y,z */
	  v = spatialVectorNewXYZ(x,y,z);
	  spatialVectorNormalize( v );
	}

	/* build index */

/*******************************************************
//
// Lookup
//
*******************************************************/

	if (argc == 1) {
	  id = spatialIndexIdByName( argv[args] );
	} else  /* lookup id by SpatialVector */
	  id = spatialIndexIdByPoint( index, v );

/*******************************************************
//
// Print result
//
*******************************************************/

	if (argc > 1) {
	  spatialVectorUpdateRaDec( v ) ;
	  printf("(x,y,z)  = %22.16f %22.16f %22.16f\n",v->x_,v->y_,v->z_);
	  printf("(ra,dec) = %22.16f %22.16f \n",v->ra_ ,v->dec_);
	  printf("ID/Name  = ");
	}
	spatialIndexNameById(id,name);
	if(hex) {
	  printf(IDFMTX,id); printf(" %s\n",name);
        } else {
	  printf(IDFMT,id); printf(" %s\n",name);
	}

	if(corner) {
	  spatialIndexNodeVertexLeaf(index,
				 spatialIndexLeafNumberById(index, id),
				 &v1,&v2,&v3);
	  printf("Corners :\n");
	  spatialVectorWrite(&v1,stdout);
	  spatialVectorWrite(&v2,stdout);
	  spatialVectorWrite(&v3,stdout);
	  printf("Corners (ra/dec):\n");
	  spatialVectorUpdateRaDec( &v1 ) ;
	  spatialVectorUpdateRaDec( &v2 ) ;
	  spatialVectorUpdateRaDec( &v3 ) ;
	  printf("%22.16f %22.16f\n",v1.ra_,v1.dec_);
	  printf("%22.16f %22.16f\n",v2.ra_,v2.dec_);
	  printf("%22.16f %22.16f\n",v3.ra_,v3.dec_);
	  printf("Differences : \n");
	  printf("%22.16f %22.16f %22.16f \n", v1.x_ - v2.x_, v1.y_ - v2.y_,
		 v1.z_ - v2.z_);
	  printf("%22.16f %22.16f %22.16f \n", v1.x_ - v3.x_, v1.y_ - v3.y_,
		 v1.z_ - v3.z_);
	  printf("%22.16f %22.16f %22.16f \n", v3.x_ - v2.x_, v3.y_ - v2.y_,
		 v3.z_ - v2.z_);
	}
	if(area) {
	  printf("AREA = %22.16f\n",spatialIndexAreaID(index,id));
	}
	return 0;
}
